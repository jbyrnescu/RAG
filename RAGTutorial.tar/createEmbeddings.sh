#!/bin/bash
source /Users/jbyrne/Dropbox/eclipse-workspace/journalTalk/venv/bin/activate

python3 embed.py chunks.txt > embeddings.tsv


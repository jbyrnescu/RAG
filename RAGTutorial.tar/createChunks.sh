#!/bin/bash
fold -w 500 combinedJournalWOTabs.txt > chunks.txt


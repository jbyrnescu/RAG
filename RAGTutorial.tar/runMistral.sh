#!/bin/bash
ollama run mistral


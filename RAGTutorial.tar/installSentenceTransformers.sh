#!/bin/bash

python3 -m venv ~/Dropbox/eclipse-workspace/journalTalk/venv
source ~/Dropbox/eclipse-workspace/journalTalk/venv/bin/activate
python3 -m pip install sentence-transformers
python3 -m pip install numpy


# pip3 install sentence-transformers


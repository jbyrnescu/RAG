#!/bin/bash
cd ~/Dropbox/eclipse-workspace/journalTalk
python3 -m venv ~/Dropbox/eclipse-workspace/journalTalk
source ~/Dropbox/eclipse-workspace/journalTalk/bin/activate

